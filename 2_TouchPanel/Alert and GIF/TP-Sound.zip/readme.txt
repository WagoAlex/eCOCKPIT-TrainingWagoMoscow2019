- Copy and create .wav files for example to /home/sounds folder 
- Copy sound.sh to /etc/config-tools/
- chmod +x /etc/config-tools/sound.sh 
--> Config-Tool shell script doesn´t work - execute permission is given, still no reaction. Maybe you can find a solution :) 

- SysProccessExecuteCommand2 works without sound.sh, but has a BLOCKING behavior!
